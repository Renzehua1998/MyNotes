using Pkg
Pkg.activate(".")
Pkg.instantiate()

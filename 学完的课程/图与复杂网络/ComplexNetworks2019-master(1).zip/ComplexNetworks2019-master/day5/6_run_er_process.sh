#!/bin/bash

julia -p 4 6_er_process.jl


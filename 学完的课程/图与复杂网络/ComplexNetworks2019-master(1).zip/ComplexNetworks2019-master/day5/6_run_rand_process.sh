#!/bin/bash

julia -p $(nproc) 6_rand_process.jl


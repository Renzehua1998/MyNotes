#!/bin/bash

julia -p 4 7_cellular_automaton.jl


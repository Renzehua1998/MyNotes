using Pkg
Pkg.activate(".")

using IJulia
notebook(dir=".")
